/*
   * Library to handle input arguments
   *
   * @author brandon tarney
   * @date  2/17/2017
   */

#ifndef getarg_h
#define getarg_h

int get_argument(int argc, char* argv[], int* return_value);

#endif
